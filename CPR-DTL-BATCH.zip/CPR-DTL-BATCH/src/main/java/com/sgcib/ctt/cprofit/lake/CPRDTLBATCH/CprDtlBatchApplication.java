package com.sgcib.ctt.cprofit.lake.CPRDTLBATCH;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CprDtlBatchApplication {

	public static void main(String[] args) {
		SpringApplication.run(CprDtlBatchApplication.class, args);
	}

}
