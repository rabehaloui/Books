package com.sgcib.ctt.cprofit.lake.CPRDTLBATCH;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CprDtlBatchApplicationTests {

	@Test
	void contextLoads() {
	}

}
